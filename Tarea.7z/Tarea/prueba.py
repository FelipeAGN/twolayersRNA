import numpy as np
import pandas as pd
df = pd.read_csv("dtrain.csv",sep = ',')
print(df)