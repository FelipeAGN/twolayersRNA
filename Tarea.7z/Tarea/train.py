# Deep-Learning:Training via BP+GD


import pandas     as pd
import numpy      as np
import my_utility as ut
	
# Softmax's training
"""
def train_softmax(x,y,param):
    .....        
    return(w,costo)
"""
# AE's Training 
def train_ae(xe,capa,lr,iteraciones):
    w1,w2 = ut.iniW_ae(xe.shape[0],capa) 
    print(w1.shape,w2.shape)           
    for i in range(iteraciones):
        a1,a2 = ut.forward_ae(w1,w2,xe)
        gw1,gw2 = ut.gradW_ae(a1,a2,xe,w2)
        w1,w2 = ut.updW_ae(w1,w2,lr,gw1,gw2)
    return(w1)

#SAE's Training 
def train_sae(xe,p_sae):
    W = []
    for capa in p_sae[2]:
        w1 =train_ae(xe,capa,p_sae[1],p_sae[0])
        W.append(w1)
        z1 = np.dot(w1,xe)
        xe = ut.act_sigmoid(z1)
    return(W,xe) 
   
# Beginning ...
def main():
    p_sae,p_sft = ut.load_config()            
    xe,ye       = ut.load_data_csv('dtrain.csv')   
    W,Xr        = train_sae(xe,p_sae)         
    #Ws, cost    = train_softmax(Xr,ye,p_sft)
    #ut.save_w_dl(W,Ws,cost)
       
if __name__ == '__main__':   
	 main()

