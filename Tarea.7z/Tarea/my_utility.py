# My Utility : auxiliars functions

from tkinter import X
import pandas as pd
import numpy  as np

# Initialize weights
def iniW_ae(prev,next):    
    w1 = iniW(next,prev)
    w2 = iniW(prev,next)
    return(w1,w2)
# Initialize one-wieght    
def iniW(next,prev):
    r = np.sqrt(6/(next+ prev))
    w = np.random.rand(next,prev)
    w = w*2*r-r    
    return(w)

# STEP 1: Feed-forward of AE
def forward_ae(w1,w2,a0):
    z1 = np.dot(w1,a0)
    a1 = act_sigmoid(z1)
    z2 = np.dot(w2,a1)
    a2 = act_sigmoid(z2)

    return(a1,a2) 

#Activation function
def act_sigmoid(z):
    return(1/(1+np.exp(-z)))   
# Derivate of the activation funciton
def deriva_sigmoid(a):
    return(a*(1-a))

# STEP 2: Feed-Backward
def gradW_ae(a1,a2,a0,w2):    
    d2 = (a2 - a0) * deriva_sigmoid(a2)
    gw2 = np.dot(d2,a1.transpose())
    d1 = np.dot(w2.transpose(),d2) * deriva_sigmoid(a1)
    gw1 = np.dot(d1,a0.transpose())
    return(gw1,gw2)    

# Update W of the AE
def updW_ae(w1,w2,lr,gw1,gw2):
    w2 = (w2 -lr) * gw2
    w1 = (w1 -lr) * gw1
    return(w1,w2)

"""
# Softmax's gradient
def grad_softmax(x,y,w,lambW):    
    ...    
    return(gW,Cost)
"""
# Calculate Softmax
def softmax(x):
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum(axis=0) 

"""
# Feed-forward of the DL
def forward_dl(x,W):        
    ...    
    return(zv)
"""    

"""
# Métrica
def metricas(...):
    ...    
    return()
"""   
#Confusion matrix
def confusion_matrix():    
    return()
#-----------------------------------------------------------------------
# Configuration of the DL 
#-----------------------------------------------------------------------
def load_config():      
    sae = []
    softmax = []
    datos_sae = np.genfromtxt("cnf_sae.csv", delimiter=',')
    datos_softmax =np.genfromtxt("cnf_softmax.csv", delimiter=',')
    
    sae.append(np.int32(datos_sae[0]))
    sae.append(np.float16(datos_sae[1]))
    sae.append(np.int32(datos_sae[2:]))
    

    
    softmax.append(np.int32(datos_softmax[0]))
    softmax.append(np.float16(datos_softmax[1]))
    softmax.append(np.float16(datos_softmax[2]))

    return(sae,softmax)

# Binary Label from raw data 

def Label_binary(x):
    return pd.get_dummies(x)
      

# Load data 
def load_data_csv(file_path):
    df = pd.read_csv(file_path,header = None)
    xe = df.iloc[:-1]
    x = df.iloc[-1,:]
    ye = Label_binary(x)
      
    return(xe,ye)
"""
# save weights of both SAE and Costo of Softmax
def save_w_dl():    
    ....
        
    
#load weight of the DL in numpy format
def load_w_dl():
    ...
    return()    

# save weights in numpy format
def save_w_npy():  
    ....
"""